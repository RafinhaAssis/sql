--CURSOR EXPLICITO E TRADICIONAL

--FOR + CURSOR
--CURSOR IMPLICITO
--CURSOR FOR UPDATE
--CURSOR COM PARAMETRO

--CURSOR EXPLICITO E TRADICIONAL

/*Cursores se comportam como os arquivos em python
Eles sao baseados em consulta

1.DECLARACAO DO CURSOR
2.ABRIR O CURSOR
3.RECUPERAR LINHA A LINHA
4.FECHAMENTO
*/
DECLARE
    CURSOR c_livro IS
    SELECT
        a.nm_autor,
        l.tx_titulo
    FROM
        t_bs_autor a INNER JOIN t_bs_livro l
        ON (a.cd_autor = l.cd_autor);
    v_nmautor t_bs_autor.nm_autor%TYPE;
    v_txtitulo t_bs_livro.tx_titulo%TYPE;
BEGIN
    OPEN c_livro;
    LOOP
        FETCH c_livro INTO v_nmautor, v_txtitulo;
        EXIT WHEN c_livro%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Livro: ' ||v_txtitulo || ' autor: ' ||v_nmautor);
    END LOOP;
    CLOSE c_livro;
END;






set serveroutput on
accept convidado prompt 'Entre com o nome do convidado';

declare
    nome varchar2(15) := '&convidado'; 
begin
    dbms_output.put_line('Bom dia '|| nome);
end;
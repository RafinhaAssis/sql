set serveroutput on
accept idade prompt 'Informe a idade'
declare
    idade_dirigir number := &idade;
begin
    if idade_dirigir >= 18 then
        dbms_output.put_line('voce ja pode dirigir');
    --elsif idade_dirigir between 16 and 17 then
    elsif  idade_dirigir >= 16 and idade_dirigir < 18 then
        dbms_output.put_line('voce ja pode ter aulas de direcao');
    else
        dbms_output.put_line('voce ainda nao pode dirigir');
    end if;
end;
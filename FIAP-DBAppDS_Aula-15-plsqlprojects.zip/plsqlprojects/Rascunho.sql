SELECT
    *
FROM
    t_bs_autor;

SELECT
    *
FROM
    t_bs_livro;

SELECT
    cd_codigo,
    tx_titulo
FROM
    t_bs_livro
WHERE
    cd_codigo = 10;
    
    
    
    
DECLARE
  dept_rec departments%ROWTYPE;
BEGIN
  -- Assign values to fields:
  
  dept_rec.department_id   := 10;
  dept_rec.department_name := 'Administration';
  dept_rec.manager_id      := 200;
  dept_rec.location_id     := 1700;
 
  -- Print fields:
 
  DBMS_OUTPUT.PUT_LINE('dept_id:   ' || dept_rec.department_id);
  DBMS_OUTPUT.PUT_LINE('dept_name: ' || dept_rec.department_name);
  DBMS_OUTPUT.PUT_LINE('mgr_id:    ' || dept_rec.manager_id);
  DBMS_OUTPUT.PUT_LINE('loc_id:    ' || dept_rec.location_id);
END;
/


    SELECT   SUM(nr_quant) 
    FROM     t_bs_livro_livraria 
    GROUP BY cd_livraria, cd_codigo; 

SELECT
    a.nm_autor,
    l.tx_titulo
FROM
    t_bs_autor a INNER JOIN t_bs_livro l
    ON (a.cd_autor = l.cd_autor);


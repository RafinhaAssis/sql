/*
REVISAO
PRINT - DBMS_OUTPUT.PUT_LINE
INPUT - antes do bloco anonimo - 
usamos o recurso do SQLPLUS + variavel de substituicao
    ACCEPT variavel PROMPT 'mensagem'

CONDICAO
    IF THEN
    ELSIF THEN
    ELSE
    END IF
*/
/*
ESTRUTURA DE DECISAO POR SELECAO
USAR O CASE
*/
/*
SET SERVEROUTPUT ON;
ACCEPT a_dia PROMPT 'Entre com o dia da semana';

DECLARE
    v_dia INTEGER := &a_dia;
BEGIN
    IF v_dia = 1 THEN
        DBMS_OUTPUT.PUT_LINE('Domingo');
    ELSIF v_dia = 2 THEN
        DBMS_OUTPUT.PUT_LINE('Segunda');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Outros dias');
    END IF;
END;
*/

SET SERVEROUTPUT ON;
ACCEPT a_dia PROMPT 'Entre com o dia da semana';

DECLARE
    v_dia INTEGER := &a_dia;
BEGIN
    CASE v_dia
    WHEN 1 THEN
        DBMS_OUTPUT.PUT_LINE('Domingo');
    WHEN 2 THEN
        DBMS_OUTPUT.PUT_LINE('Segunda');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Outros dias');
    END CASE;
END;






set serveroutput on
begin
    -- � o print
    dbms_output.put_line('Hello World');
end;
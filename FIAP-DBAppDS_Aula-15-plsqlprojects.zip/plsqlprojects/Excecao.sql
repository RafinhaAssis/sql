/*EXCECAO PLSQL
igual ao PYTHON
*/
-- TRATAMENTO DE EXCE��O
/*
SET SERVEROUTPUT ON
DECLARE
    v_valor NUMBER := 70;
    v_qtd NUMBER :=0;
    media NUMBER;
BEGIN
    media := v_valor / v_qtd;
    DBMS_OUTPUT.PUT_LINE('A media �' || media);
EXCEPTION
--    WHEN ZERO_DIVIDE THEN
--        DBMS_OUTPUT.PUT_LINE('Houve uma divisao por zero');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Houve uma excecao ' || SQLERRM );    
END;
*/


-- LANCAMENTO DE EXCE��O

SET SERVEROUTPUT ON
DECLARE
    v_valor NUMBER := -70;
    v_qtd NUMBER := 0;
    media NUMBER;
    QUANTIDADE_NEGATIVA EXCEPTION;
BEGIN
    IF v_valor < 0 OR v_qtd < 0 THEN
        RAISE QUANTIDADE_NEGATIVA;
    END IF;
    media := v_valor / v_qtd;
    DBMS_OUTPUT.PUT_LINE('A media �' || media);
EXCEPTION
    WHEN ZERO_DIVIDE THEN
        DBMS_OUTPUT.PUT_LINE('Houve uma divisao por zero');
    WHEN QUANTIDADE_NEGATIVA THEN
        DBMS_OUTPUT.PUT_LINE('A quantidade ou valor � negativo');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Houve uma excecao ' || SQLERRM );    
END;


-- LANCAMENTO DE EXCE��O
SET SERVEROUTPUT ON
DECLARE
    v_valor NUMBER := -70;
    v_qtd NUMBER := 0;
    media NUMBER;
BEGIN
    IF v_valor < 0 OR v_qtd < 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Valor Negativo');
    END IF;
    media := v_valor / v_qtd;
    DBMS_OUTPUT.PUT_LINE('A media �' || media);
EXCEPTION
    WHEN ZERO_DIVIDE THEN
        DBMS_OUTPUT.PUT_LINE('Houve uma divisao por zero');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Houve uma excecao ' || SQLERRM );    
END;
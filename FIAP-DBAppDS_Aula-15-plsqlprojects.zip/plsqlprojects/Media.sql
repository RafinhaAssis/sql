set serveroutput on;
accept valor2 prompt 'Digite o segundo valor';

declare
    n1 number := 0;
    n2 number := &valor2;
    media number;
begin
    --n1 := 10;
    --n2 := 5;
    media := (n1 + n2)/2;
    dbms_output.put_line('A media � ' || media);
end;
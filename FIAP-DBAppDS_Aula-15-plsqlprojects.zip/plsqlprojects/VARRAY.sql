--VARRAY
-- O vetor � uma especie de lista do python

-- O nosso exemplo � declarar uma lista de numeros
SET SERVEROUTPUT ON;
DECLARE
    TYPE VETOR_NUM_5_ELEMENTOS IS VARRAY(5) OF INTEGER;
    lista_idades VETOR_NUM_5_ELEMENTOS;
    
BEGIN
    lista_idades := VETOR_NUM_5_ELEMENTOS(12, 34, 7, 8, 87);
    FOR i IN 1..5
    LOOP
        DBMS_OUTPUT.PUT_LINE('A idade � '|| lista_idades(i));
    END LOOP;
END;
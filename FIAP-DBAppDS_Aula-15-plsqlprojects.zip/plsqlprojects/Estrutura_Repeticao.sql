--ESTRUTURA DE REPETICAO

--ESTRUTURA DE REPETICAO ITERATIVA LOOP
/*
SET SERVEROUTPUT ON
ACCEPT a_numero PROMPT 'Entre com o numero da tabuada';
DECLARE
    v_numero INTEGER := &a_numero;
    tabuada INTEGER;
    i INTEGER;
BEGIN
    FOR i IN 1..10 
    LOOP
        tabuada := i * v_numero;
        DBMS_OUTPUT.PUT_LINE(v_numero || ' X ' || i || ' = ' || tabuada);
    END LOOP;
END;
*/


--ESTRUTURA DE REPETICAO INTERATIVA WHILE
/*
SET SERVEROUTPUT ON
ACCEPT a_numero PROMPT 'Entre com o numero da tabuada';
DECLARE
    v_numero INTEGER := &a_numero;
    tabuada INTEGER;
    i INTEGER := 1;
BEGIN
    WHILE i <= 10 
    LOOP
        tabuada := i * v_numero;
        DBMS_OUTPUT.PUT_LINE(v_numero || ' X ' || i || ' = ' || tabuada);
        i := i + 1;
    END LOOP;
END;
*/

--ESTRUTURA DE REPETICAO INTERATIVA POS CONDICAO LOOP EXIT WHEN
SET SERVEROUTPUT ON
ACCEPT a_numero PROMPT 'Entre com o numero da tabuada';
DECLARE
    v_numero INTEGER := &a_numero;
    tabuada INTEGER;
    i INTEGER := 1;
BEGIN
    LOOP
        EXIT WHEN i > 10; 
        tabuada := i * v_numero;
        DBMS_OUTPUT.PUT_LINE(v_numero || ' X ' || i || ' = ' || tabuada);
        i := i + 1;
    END LOOP;
END;


/*
SET SERVEROUTPUT ON;
DECLARE
    v_codigo INTEGER;
    v_titulo VARCHAR2(200);
BEGIN
    SELECT
        cd_codigo,
        tx_titulo
    INTO
        v_codigo,
        v_titulo
    FROM
        t_bs_livro
    WHERE
        cd_codigo = 10;
    DBMS_OUTPUT.PUT_LINE('O titulo � '||v_titulo);
END;
*/

SET SERVEROUTPUT ON;
DECLARE
--    v_codigo INTEGER;
--    v_titulo VARCHAR2(200);
    v_codigo t_bs_livro.cd_codigo%TYPE;
    v_titulo t_bs_livro.tx_titulo%TYPE;
    i INTEGER := 10;
BEGIN
    WHILE i <= 15
    LOOP
        SELECT
            cd_codigo,
            tx_titulo
        INTO
            v_codigo,
            v_titulo
        FROM
            t_bs_livro
        WHERE
            cd_codigo = i;
        DBMS_OUTPUT.PUT_LINE('O titulo � '||v_titulo);
        i := i + 1;
    END LOOP;
END;

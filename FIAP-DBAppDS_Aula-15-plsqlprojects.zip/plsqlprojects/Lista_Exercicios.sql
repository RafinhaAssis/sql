/*
1.	Escreva um bloco an�nimo que reupere os titulos dos livros cujos codigos estejam entre 10 e 15. 
Use %TYPE para declarar a vari�vel que vai receber o titulo do livro
*/
/*
SET SERVEROUTPUT ON;
DECLARE
--    v_codigo INTEGER;
--    v_titulo VARCHAR2(200);
    v_codigo t_bs_livro.cd_codigo%TYPE;
    v_titulo t_bs_livro.tx_titulo%TYPE;
    i INTEGER := 10;
BEGIN
    WHILE i <= 15
    LOOP
        SELECT
            cd_codigo,
            tx_titulo
        INTO
            v_codigo,
            v_titulo
        FROM
            t_bs_livro
        WHERE
            cd_codigo = i;
        DBMS_OUTPUT.PUT_LINE('O titulo � '||v_titulo);
        i := i + 1;
    END LOOP;
END;
*/

/*
2.	Baseado no bloco an�nimo anterior recupere agora todos 
os campos da tabela T_BS_LIVRO. 
Pequise %ROWTYPE e use na declaracao da sua vari�vel
*/
/*
SET SERVEROUTPUT ON;
DECLARE
    i INTEGER := 10;
    l_livro t_bs_livro%ROWTYPE;
BEGIN
    LOOP
        EXIT WHEN i > 15;
        SELECT
            cd_codigo,
            tx_titulo,
            nr_numero_paginas,
            nr_ano_publicacao,
            nr_edicao,
            cd_autor
        INTO
            l_livro.cd_codigo,
            l_livro.tx_titulo,
            l_livro.nr_numero_paginas,
            l_livro.nr_ano_publicacao,
            l_livro.nr_edicao,
            l_livro.cd_autor
        FROM
            t_bs_livro
        WHERE
            cd_codigo = i;
        DBMS_OUTPUT.PUT_LINE('O titulo � '||l_livro.tx_titulo || ' e o cod do autor � ' ||l_livro.cd_autor);
        i := i + 1;
    END LOOP;
END;
*/

/*
3.	Observe o trecho abaixo e execute no Oracle. Explique o que aconteceu
DECLARE 
    qtde   t_bs_livro_livraria.nr_quant%type; 
BEGIN 
    SELECT   SUM(nr_quant) 
    INTO     qtde 
    FROM     t_bs_livro_livraria 
    GROUP BY cd_livraria, cd_codigo; 
    dbms_output.put_line('Qtde livros= ' || qtde); 
END; 
*/

DECLARE 
    qtde   t_bs_livro_livraria.nr_quant%type; 
BEGIN 
    SELECT   SUM(nr_quant) 
    INTO     qtde 
    FROM     t_bs_livro_livraria 
    GROUP BY cd_livraria, cd_codigo; 
    dbms_output.put_line('Qtde livros= ' || qtde); 
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('Houve um errro ' || SQLERRM); 
END; 





